# 2FA Application with Docker

A comprehensive two-factor authentication (2FA) application built with FastAPI (backend) and React/Vue (frontend), containerized with Docker.

## Prerequisites

- [Docker](https://www.docker.com/get-started)
- [Docker Compose](https://docs.docker.com/compose/install/)

## Quick Start

1. Clone or download this repository
2. Navigate to the project directory:
   ```bash
   cd 2FA-APP
   ```
3. Build and start the application:
   ```bash
   docker-compose up --build
   ```
4. Wait for all services to start (1-2 minutes)
5. Access the application:
   - Frontend: [http://localhost:8080](http://localhost:8080)
   - Backend API: [http://localhost:8000](http://localhost:8000)
   - API Documentation: [http://localhost:8000/docs](http://localhost:8000/docs)

## Project Structure

```
2FA-APP/
├── docker-compose.yml          # Docker Compose configuration
├── backend/                    # Backend service
│   ├── Dockerfile              # Backend Docker configuration
│   ├── main.py                 # FastAPI application
│   ├── requirements.txt        # Python dependencies
│   └── db.sql                  # Database schema
└── frontend/                   # Frontend service
    ├── Dockerfile              # Frontend Docker configuration
    ├── package.json            # Node.js dependencies
    └── ...                     # Frontend source files
```

## Services

### Backend (FastAPI)
- Port: 8000
- Language: Python 3.10
- Framework: FastAPI
- Database: MySQL 8.0

### Frontend (React/Vue)
- Port: 8080
- Built with Node.js and Nginx

### Database (MySQL)
- Port: 3306 (internal)
- Root password: `root_password`
- Database name: `mydatabase`
- Data persistence via Docker volumes

## API Endpoints

The backend provides the following endpoints:

- `POST /register` - Register a new user
- `POST /login` - Login with username/password
- `POST /2fa/enable` - Enable 2FA for a user
- `POST /2fa/confirm` - Confirm 2FA setup
- `POST /2fa/verify` - Verify 2FA code
- `GET /me` - Get current user info
- `GET /dashboard` - Access user dashboard
- `GET /docs` - Interactive API documentation (Swagger UI)

### Example API Usage

**Register a new user:**
```bash
curl -X POST "http://localhost:8000/register" \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"testpass"}'
```

**Login:**
```bash
curl -X POST "http://localhost:8000/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"testpass"}'
```

## Database Management

### Accessing the Database

Connect to the MySQL database using Docker:

```bash
# Execute single command
docker exec 2fa-app-db-1 mysql -u root -proot_password -e "USE mydatabase; SELECT * FROM users;"

# Enter interactive MySQL mode
docker exec -it 2fa-app-db-1 mysql -u root -proot_password mydatabase
```

### Check Database Schema

```bash
docker exec 2fa-app-db-1 mysql -u root -proot_password -e "USE mydatabase; DESCRIBE users;"
```

### View All Users

```bash
docker exec 2fa-app-db-1 mysql -u root -proot_password -e "USE mydatabase; SELECT id, username, otp_enabled FROM users;"
```

## Docker Compose Commands

### Build and Start Services
```bash
docker-compose up --build
```

### Start Services in Background
```bash
docker-compose up --build -d
```

### Stop Services
```bash
docker-compose down
```

### View Service Logs
```bash
docker-compose logs
docker-compose logs backend
docker-compose logs frontend
docker-compose logs db
```

### Rebuild Specific Service
```bash
docker-compose build backend
docker-compose up --build backend
```

## Environment Configuration

The application uses the following environment variables (defined in docker-compose.yml):

- `MYSQL_ROOT_PASSWORD`: Root password for MySQL
- `MYSQL_DATABASE`: Database name
- `MYSQL_USER`: Database user
- `MYSQL_PASSWORD`: Database user password

## Troubleshooting

### Common Issues

1. **Port already in use**
   - Make sure ports 8000 and 8080 are available
   - Change ports in docker-compose.yml if needed

2. **Database connection errors**
   - Make sure all services are running: `docker-compose ps`
   - Check backend logs: `docker-compose logs backend`

3. **Build errors**
   - Clear Docker cache: `docker system prune -a`
   - Rebuild: `docker-compose up --build`

### Useful Commands

```bash
# Check running containers
docker-compose ps

# Get shell access to backend
docker-compose exec backend sh

# Get shell access to frontend
docker-compose exec frontend sh

# Get MySQL CLI access
docker-compose exec db mysql -u root -proot_password mydatabase

# View backend logs
docker-compose logs backend

# Follow logs in real time
docker-compose logs -f backend
```

## Stopping the Application

To stop the running services:
```bash
# Press Ctrl+C in the terminal where you ran 'docker-compose up'

# Or in another terminal:
docker-compose down
```

## Development

For development, you can modify the source files in the `backend/` and `frontend/` directories. The services will automatically pick up changes depending on your configuration.

## Production Notes

This setup is suitable for development and testing. For production deployment, consider:
- Using environment variables for sensitive data
- Implementing proper SSL certificates
- Adding a reverse proxy (nginx) for production
- Setting up proper logging and monitoring
- Using persistent storage for database

## License

[Add your license here]